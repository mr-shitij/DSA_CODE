# Search-Engine-Using-Splay-Trees-in-C
Command line arguments (how to access functions)

1. {.\main –s whatever you want to search} : Make a search (Insert) 
2. {.\main –a prefix} : Access previous searches using prefix
3. {.\main –d} : Display all searches 
4. Get frequently searched data 
	{.\main –f} : for both least and most frequently searched
	{.\main –f m} : for most frequently searched
	{.\main –f l} : for least frequently searched
5.   {.\main –r} : Get recently searched
6.   {.\main –h} : Display search history from file 
7.   {.\main –c} : Clear search history 
8.   {.\main –j keyword} : Give suggestions to search using keyword 
