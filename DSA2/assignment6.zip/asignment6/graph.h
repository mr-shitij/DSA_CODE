#include "list.h"

typedef struct graph
{
	int v;
	struct list **adjMtrx;
	int **Mtrx;
	int *visited_BFS;
	int *visited_DFS;
}graph;

//Functions prototype

graph *inti_graph(graph *g);
void in_degree(graph *g);
void out_degree(graph *g);
void display_mtrx(graph *g);
graph *create_graph(graph *g);
void print_graph_mtrx(graph *g);
