typedef struct list
{
	int data;
	struct list *next;
}list;

list *create_node(int data);
