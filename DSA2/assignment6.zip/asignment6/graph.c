#include<stdio.h>
#include<stdlib.h>
#include"graph.h"
#include "BFS.h"
#include "DFS.h"

graph *init_graph(graph *g)
{
	printf("\nEnter Number of vertex :");
	scanf("%d",&g -> v);
	
	g -> adjMtrx = malloc(sizeof(struct list*) * (g -> v));	
	g -> visited_BFS = malloc(sizeof(int) * g -> v);
	g -> visited_DFS = malloc(sizeof(int) * g -> v);

    	for (int i = 0; i < g -> v; ++i) {
		g -> adjMtrx[i] = create_node(i);
		g -> visited_BFS[i] = 0;
		g -> visited_DFS[i] = 0;
    	}
	
	return g;
	

}

graph *create_graph(graph *g)
{
	if( g == NULL)
		return NULL;
	
	int src,dest,choice;
	while(1)
	{
		printf("\nEnter edges : ig. \" 1 2 \" : ");
		scanf("%d%d",&src,&dest);
		
		list* temp = g -> adjMtrx[src];
		
		while(temp -> next != NULL)
			temp = temp -> next;
		
		temp -> next = create_node(dest);
		
		temp = g -> adjMtrx[dest];
		
		while(temp -> next != NULL)
			temp = temp -> next;
			
		temp -> next = create_node(src);
		
		printf("Wants to continue (1-Yes 2-No)): ");
		scanf("%d",&choice);
		
		if(choice == 1)
			continue;
		else
			break;
	}
	
	return g;
}

void print_graph_mtrx(graph *g)
{
	int v;
  for (v = 0; v < g -> v; v++) 
  {
     list* temp = g -> adjMtrx[v];
     printf("\n Vertex %d\n: ", v);
     
     while (temp) 
     {
      printf("%d -> ", temp -> data);
      temp = temp->next;
    }
    
    printf("\n");
  }
}

void display_mtrx(graph *g)
{
	
	g -> Mtrx = malloc(sizeof(int*) * g -> v);
	
	for(int i=0; i < g -> v; i++)
	{
		g -> Mtrx[i] = malloc(sizeof(int) * g -> v);
	}
	
	for(int i=0; i < g -> v; i++)
	{
		for(int j = 0; j < g -> v; j++)
		{
			g -> Mtrx[i][j] = 0;
		}
	}
	
	
	for(int i = 0; i < g -> v; i++)
	{
		list *temp = g -> adjMtrx[i];
		
		while(temp -> next != NULL)
		{
			temp = temp -> next;
			g -> Mtrx[i][temp -> data] = 1;
			g -> Mtrx[temp -> data][i] = 1;
			
		}		
	}
	
	for(int i = 0; i < (g -> v); ++i)	
	{
		for(int j = 0; j < (g -> v); ++j)
			printf("%d\t",g -> Mtrx[i][j]);
		printf("\n");
	}
}

void out_degree(graph *g)
{
	
	for(int i = 0; i < g -> v; i++)
	{
	int count = 0;
	list *temp = g -> adjMtrx[i];
	printf("\nOut-degree of vertex %d : ",i);
	
	while(temp -> next != NULL){
	count+=1;
	temp = temp -> next;
	}
	
	printf("%d\n",count);
	}
}

void in_degree(graph *g)
{
	for(int i = 0; i < g -> v; i++)
	{
		int count = 0;
	//	list *temp = g -> adjMtrx[i];
		printf("\nIn-degree of vertex %d :",i);
		
		for(int j = 0; j < g -> v; j++)
		{
			list *temp1 = g -> adjMtrx[j];
			while(temp1 -> next != NULL){
			
			temp1 = temp1 -> next;
			
			if( i == temp1 -> data)
				count+=1;
			
	}
		}
		printf("%d\n",count);
	}
}

void main()
{
	graph *g = (struct graph*)malloc(sizeof(struct graph));
	g = init_graph(g);
	g = create_graph(g);
	printf("\nList of graph at each vertex : \n");
	print_graph_mtrx(g);
	printf("\nGraph in matrix form : \n");
	display_mtrx(g);
	printf("\nBreath first search traversal of graph : \n");
	bfs(g,0);
	printf("\nDepth first search traversal of graph : \n");
	DFS(g,0);
	in_degree(g);
	out_degree(g);
}
