#include <stdio.h>
#include <stdlib.h>
#include "list.h"

list *create_node(int data)
{
	list *node = (struct list*)malloc(sizeof(struct list));
	node -> data = data;
	node -> next = NULL;
	
	return node;
}

