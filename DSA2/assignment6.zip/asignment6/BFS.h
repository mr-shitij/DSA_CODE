//#include "graph.h"

#define SIZE 40

typedef struct queue {
  int items[SIZE];
  int front;
  int rear;
}queue;

queue* createQueue();
void enqueue(queue* q, int data);
int dequeue(queue* q);
void display(queue* q);
int isEmpty(queue* q);
void bfs(graph* g, int startVertex);
