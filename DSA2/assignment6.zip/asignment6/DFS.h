void  DFS(graph* g, int data);
