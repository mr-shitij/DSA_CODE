#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
#include "DFS.h"

// DFS algo
void DFS(graph* graph, int vertex) {
  list* temp = graph->adjMtrx[vertex];
 // list* temp = adjList;

  graph->visited_DFS[vertex] = 1;
  printf("%d ->", vertex);

  while (temp != NULL) {
    int connectedVertex = temp->data;

    if (graph->visited_DFS[connectedVertex] == 0) {
      DFS(graph, connectedVertex);
    }
    temp = temp->next;
  }
}

