#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
#include "BFS.h"


// Create a queue
queue* createQueue() {
  queue* q = malloc(sizeof(struct queue));
  q->front = -1;
  q->rear = -1;
  return q;
}

// Check if the queue is empty
int isEmpty(queue* q) {
  if (q->rear == -1)
    return 1;
  else
    return 0;
}

// Adding elements into queue
void enqueue(queue* q, int value) {
  if (q->rear == SIZE - 1)
    printf("\nQueue is Full!!");
  else {
    if (q->front == -1)
      q->front = 0;
    q->rear++;
    q->items[q->rear] = value;
  }
}

// Removing elements from queue
int dequeue(queue* q) {
  int item;
  if (isEmpty(q)) {
    printf("Queue is empty");
    item = -1;
  } else {
    item = q->items[q->front];
    q->front++;
    if (q->front > q->rear) {
      q->front = q->rear = -1;
    }
  }
  return item;
}

void bfs(graph *graph, int startVertex) {
   queue* q = createQueue();

  graph->visited_BFS[startVertex] = 1;
  enqueue(q, startVertex);

  while (!isEmpty(q)) {
    int currentVertex = dequeue(q);
    printf("%d ->", currentVertex);

     list* temp = graph->adjMtrx[currentVertex];

    while (temp) {
      int adjVertex = temp->data;

      if (graph->visited_BFS[adjVertex] == 0) {
        graph->visited_BFS[adjVertex] = 1;
        enqueue(q, adjVertex);
      }
      temp = temp->next;
    }
  }
}
