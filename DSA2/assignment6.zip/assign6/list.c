#include <stdio.h>
#include <stdlib.h>
#include "list.h"

list *create_node(int data, int weight)
{
	list *node = (struct list*)malloc(sizeof(struct list));
	node -> vertex = data;
	node -> weight = weight;
	node -> next = NULL;
	
	return node;
}

