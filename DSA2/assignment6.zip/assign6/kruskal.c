#include<stdio.h>
#include<stdlib.h>
#include"graph.h"
#include"kruskal.h"

void kruskal(graph *g)
{
	list *temp2 = (struct list*)malloc(sizeof(struct list));
	int min = 0;
	//printf("\nin algoo Hii");
	for(int i = 0; i < g -> v; i++)
	{
		//printf("\nin for Hii");
		list *temp = g -> adjMtrx[i];
		
		min = temp -> weight;
		list *temp1 = temp -> next;
		temp2 = NULL;
		if(temp1)
		{
			temp2 = temp1 -> next;
		}
		
		if(!temp1)
			continue;
		
		if(!temp2)
		{
			g -> visited[temp -> vertex];
			g -> visited[temp1 -> vertex];
			g -> spanMtrx[temp -> vertex][temp1 -> vertex] = 1;
			g -> spanMtrx[temp1 -> vertex][temp -> vertex] = 1;
		}
		else
		{
		
		while(temp2 != NULL)
		{
			if(g -> visited[temp1 -> vertex] == 1)
			{
				temp1=temp2;
				temp2 = temp2->next;
			}
			
			//temp1 = temp -> next;
			else if(temp1 -> weight < temp2 -> weight)
			{
				if(g -> visited[temp1 -> vertex] == 0)
				{
					
						temp2 = temp2 -> next;	
			
				}
			}
			
			else if(temp1 -> weight == temp2 -> weight)
			{
				if(g -> visited[temp1 -> vertex] == 0)
				{
					
						temp2 = temp2 -> next;	
			
				}
				else
				{
					
					if(temp2)
					{
					temp1 = temp2;
					temp2 = temp2 -> next;	
					}
				}
				
			}
			else
			{
			
				if(temp2)
				{
				temp1 = temp2;
				temp2 = temp2 -> next;	
				}
			}
			
		}
	
		
		g -> spanMtrx[temp -> vertex][temp1 -> vertex] = 1;
		g -> visited[temp -> vertex] = 1;
		g -> visited[temp1 -> vertex] = 1;
		
		}		
	}	
}
