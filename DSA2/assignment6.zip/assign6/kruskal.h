

void kruskal(graph *g);
