typedef struct list
{
	int vertex;
	int weight;
	struct list *next;
}list;

list *create_node(int data, int weight);
