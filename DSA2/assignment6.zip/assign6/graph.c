#include<stdio.h>
#include<stdlib.h>
#include"graph.h"
#include"kruskal.h"

graph *init_graph(graph *g)
{
	printf("\nEnter Number of vertex :");
	scanf("%d",&g -> v);
	
	g -> adjMtrx = malloc(sizeof(struct list*) * (g -> v));	
	g -> visited = malloc(sizeof(int) * g -> v);

    	for (int i = 0; i < g -> v; ++i) {
		g -> adjMtrx[i] = create_node(i,0);
		g -> visited[i] = 0;
    	}
    	
    	g -> Mtrx = malloc(sizeof(int*) * g -> v);
	g -> spanMtrx = malloc(sizeof(int*) * g -> v);

	
	for(int i=0; i < g -> v; i++)
	{
		g -> Mtrx[i] = malloc(sizeof(int) * g -> v);
		g -> spanMtrx[i] = malloc(sizeof(int) * g -> v);
	}
	
	for(int i=0; i < g -> v; i++)
	{
		for(int j = 0; j < g -> v; j++)
		{
			g -> Mtrx[i][j] = 0;
			g -> spanMtrx[i][j] = 0;
		}
	}
	
	return g;
	

}

graph *create_graph(graph *g)
{
	if( g == NULL)
		return NULL;
	
	int src,dest,choice,wght;
	while(1)
	{
		printf("\nEnter edges : ig. \" 1 2 \" : ");
		scanf("%d%d",&src,&dest);
		printf("\nEnter weight :");
		scanf("%d",&wght);
		
		list* temp = g -> adjMtrx[src];
		
		while(temp -> next != NULL)
			temp = temp -> next;
		
		temp -> next = create_node(dest,wght);
		
		temp = g -> adjMtrx[dest];
		
		while(temp -> next != NULL)
			temp = temp -> next;
			
		temp -> next = create_node(src,wght);
		
		printf("Wants to continue (1-Yes 2-No)): ");
		scanf("%d",&choice);
		
		if(choice == 1)
			continue;
		else
			break;
	}
	
	return g;
}

void print_graph_mtrx(graph *g)
{
	int v;
  for (v = 0; v < g -> v; v++) 
  {
     list* temp = g -> adjMtrx[v];
     printf("\n Vertex %d\n: ", v);
     
     while (temp) 
     {
      printf("%d -> ", temp -> vertex);
      temp = temp->next;
    }
    
    printf("\n");
  }
}

void display_mtrx(graph *g)
{

	for(int i = 0; i < g -> v; i++)
	{
		list *temp = g -> adjMtrx[i];
		
		while(temp -> next != NULL)
		{
			temp = temp -> next;
			g -> Mtrx[i][temp -> vertex] = temp -> weight;
			g -> Mtrx[temp -> vertex][i] = temp -> weight;
			
		}		
	}
	
	for(int i = 0; i < (g -> v); ++i)	
	{
		for(int j = 0; j < (g -> v); ++j)
			printf("%d\t",g -> Mtrx[i][j]);
		printf("\n");
	}
}



void main()
{
	graph *g = (struct graph*)malloc(sizeof(struct graph));
	g = init_graph(g);
	g = create_graph(g);
	printf("\nList of graph at each vertex : \n");
	print_graph_mtrx(g);
	printf("\nGraph in matrix form : \n");
	display_mtrx(g);
	printf("\nSpan tree in matrix form : \n");
	kruskal(g);
	for(int i = 0; i < (g -> v); ++i)	
	{
		for(int j = 0; j < (g -> v); ++j)
			printf("%d\t",g -> spanMtrx[i][j]);
		printf("\n");
	}
}
