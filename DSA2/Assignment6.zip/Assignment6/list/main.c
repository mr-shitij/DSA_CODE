#include <stdio.h>
#include "graph.h"


int main() {
	Graph h;
	init_graph(&h, "data.txt");
	print(h);
	return 0;
}
