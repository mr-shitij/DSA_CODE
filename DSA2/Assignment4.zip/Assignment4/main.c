#include<stdio.h>
#include "AVL.h"

int main(){
	AVL root;
	initAVL(&root);
	while(1) {
		int command=0;
		printf("1.Insert all months \n2.Remove a month \n3.Display \n4.Delete all \n5.Exit\n");
		printf("Enter Your Choice : \n");
		scanf("%d", &command);
		if(command < 1 || command > 5){
			printf("Enter a valid number to proceed.....");
			continue;
		}
		switch (command) {
			char month[10];
			int level;
			case 1: 
				insertNode(&root,"Jan");
				insertNode(&root,"Feb");
				insertNode(&root,"Mar");
				insertNode(&root,"Apr");
				insertNode(&root,"May");
				insertNode(&root,"Jun");
				insertNode(&root,"Jul");
				insertNode(&root,"Aug");
				insertNode(&root,"Sept");
				insertNode(&root,"Oct");
				insertNode(&root,"Nov");
				insertNode(&root,"Dec");
				printf("All months succesfully inserted ..!!\n");
				break;
			case 2:
				printf("Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sept, Oct, Nov, Dec\n");
				printf("Enter Month to delete : ");
				scanf("%s",month);
				removeNode(&root,month);
				break;
			case 3:
				traverse(root);
				break;
			case 4:
				destroy(&root);
				break;
			default:
				break;
		}
		if(command==5) 
			break;
	}
	return 0;
}
