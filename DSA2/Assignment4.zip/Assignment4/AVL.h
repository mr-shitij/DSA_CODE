typedef struct AVLNode {
	char month[10];
	struct AVLNode *left;
	struct AVLNode *right;
	struct AVLNode *parent;
	int balanceFactor;
} AVLNode;

typedef AVLNode* AVL;


void initAVL(AVL* root);
void insertNode(AVL* root,char* month);
void removeNode(AVL* root,char * month);
void traverse(AVL root);
void destroy(AVL* root);

