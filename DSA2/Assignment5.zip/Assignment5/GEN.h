#include<stdio.h>

void generate_random_data(char file_name[], int no);
void print_data(char file_name[]);


