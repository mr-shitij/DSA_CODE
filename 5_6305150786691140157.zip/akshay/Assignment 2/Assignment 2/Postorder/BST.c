#include <stdio.h>
#include <stdlib.h>
#include "BST.h"

void inorder(BST tree){

	if(tree == NULL)
		return;

	inorder(tree -> left);
	printf("%d ", tree -> key);
	inorder(tree -> right);

	return;

}

BST makeTree(int *post, int index, int size){

	BST nn;
	int i;
	
	if(index > size)
		return NULL;
	
	nn = (node *)malloc(sizeof(node));
	nn -> key = post[size];
	nn -> right = NULL;
	nn -> left = NULL;

	for(i = size - 1; i >= index; i--){

		if(post[i] < nn -> key)
			break;

	}

	nn -> right = makeTree(post, i + 1, size - 1);

	nn -> left = makeTree(post, index, i);

	return nn;
}
