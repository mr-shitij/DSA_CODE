typedef struct node{

	int key;
	struct node *left, *right;

}node;

typedef node* BST;

void inorder(BST);
BST makeTree(int *post, int size, int index);
