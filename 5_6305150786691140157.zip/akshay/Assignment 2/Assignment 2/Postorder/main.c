#include <stdio.h>
#include "BST.h"
#include <stdlib.h>

int main(){

	BST tree;
	int *postorder, size;

	printf("Enter the size");
	scanf("%d", &size);

	postorder = (int *)malloc(sizeof(int)*size);

	printf("Enter the postorder representation\n");
	for(int i = 0; i < size; i++){

		scanf("%d", postorder + i);

	}

	tree = makeTree(postorder, 0, size - 1);

	printf("Inorder Traversal\n");
	inorder(tree);

	return 0;

}
