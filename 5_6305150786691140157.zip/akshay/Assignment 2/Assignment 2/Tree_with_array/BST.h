#define MAX_SIZE 10

typedef struct BST{

	int *array;
	int size;

}BST;

void initBST(BST* );
void insert_node(BST *, int);
int search(BST, int);
void remove_node(BST, int);
void recursive_traversal(BST);
int isComplete(BST, int);
void inorder(BST, int);
void postorder(BST, int);
void preorder(BST, int);
int count(BST, int);
