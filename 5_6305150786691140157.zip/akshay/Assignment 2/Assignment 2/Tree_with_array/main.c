#include <stdio.h>
#include "BST.h"
#include <stdlib.h>

int main(void){

    BST t;
    int found;

    initBST(&t);
    
    insert_node(&t, 32);
    insert_node(&t, 12); 
    insert_node(&t, 40);
    insert_node(&t, 29);
    insert_node(&t, 9);
    insert_node(&t, 38);
    insert_node(&t, 45);
    insert_node(&t, 15);
    insert_node(&t, 22);
    insert_node(&t, 79);
    insert_node(&t, 100);
/*	
    remove_node(t, 12);
    remove_node(t, 13);

    found = search(t, 29);
    printf("found/not found %d\n", found);
    found = search(t, 11);
    printf("found/not found %d\n", found);
    */

    recursive_traversal(t);
    
    int number_of_nodes = count(t, 0) - 1;

    printf("\nIs complete %d \n", isComplete(t, number_of_nodes));

    return 0;

}
