#include <stdio.h>
#include "BST.h"
#include <limits.h>
#include <stdlib.h>

void initBST(BST *t){

	BST tree = *t;

	tree.array = (int *)malloc(sizeof(int)*10);
	tree.size = 10;

    for(int i = 0; i < tree.size; i++){

        //Inititalizing the tree by assigning every element in the array with INT_MIN
        tree.array[i] = INT_MIN;

    }

    *t = tree;

    return;
}

void insert_node(BST *t, int data){

	BST tree = *t;
    int i = 0;

    if(tree.array[0] == INT_MIN){
        tree.array[0] = data;
        return;
    }

    //Returning back to the loop after reallocating the array
    loop:
    while((tree.array[i] != INT_MIN)&&(i < tree.size)){

        if(data < tree.array[i]){

            i = 2*i + 1;

        }
        else if(data > tree.array[i]){

            i = 2*i + 2;

        }
        else
            return;

    }

    //If the position exceeds the array size reallocate the array to twice its original size
    if(i >= tree.size){
        tree.array = (int *)realloc(tree.array, sizeof(int)*tree.size*2);
        for(int j = tree.size; j < tree.size*2; j++)
            tree.array[j] = INT_MIN;

	    tree.size *= 2;
        goto loop;
    }

    tree.array[i] = data;

    *t = tree;
    return;

}

/*
void remove_node(BST *tree, int data){

    int i = 0;

    //Checking the condition for empty tree
    if(tree[0] == INT_MIN){
        printf("Node cannot be removed from an empty tree\n");
        return;

    }

    //Searching the required node
    while((tree[i] != data)&&(i < tree.size)){

        if(data < tree[i]){

            i = 2*i + 1;

        }
        else
            i = 2*i + 2;

    }

    if(i >= tree.size){
        printf("Element not found\n");
        return;
    }

    tree[i] = INT_MIN;

    return;

}
*/

int search(BST tree, int data){

    int i = 0;
    if(tree.array[0] == INT_MIN){
        printf("Empty tree\n");
        return 0;
    }

    while((tree.array[i] != data)&&(i < tree.size)){

        if(data < tree.array[i])
            i = 2*i + 1;
        else
            i = 2*i + 2;

    }

    if(i >= tree.size)
        return 0;

    return 1;

}

int isComplete(BST tree, int number_of_nodes){

	for(int i = 0; i < number_of_nodes; i++){

		if(tree.array[i] == INT_MIN)
			return 0;

	}

	return 1;

}

void recursive_traversal(BST tree){

    printf("\nInorder traversal --> \n");
    inorder(tree, 0);

    printf("\nPostorder Traversal --> \n");
    postorder(tree, 0);

    printf("\nPreorder Traversal -->\n");
    preorder(tree, 0);

    return;

}

void inorder(BST tree, int index){

    if((index >= 0)&&(index < tree.size)){

       //Traversing to the left subtree
       inorder(tree, 2*index + 1);

       
       if(tree.array[index] != INT_MIN)
            printf("%d ", tree.array[index]);

       //traversing to the right sub tree
       inorder(tree, 2*index + 2);

    }

    return;

}

void postorder(BST tree, int index){

    if((index >= 0)&&(index < tree.size)){

        postorder(tree, 2*index + 1);
        postorder(tree, 2*index + 2);
 
	    if(tree.array[index] != INT_MIN)
            printf("%d ", tree.array[index]);

    }

    return;

}

void preorder(BST tree, int index){

    if((index >= 0)&&(index < tree.size)){

	    
        if(tree.array[index] != INT_MIN)
            printf("%d ", tree.array[index]);

        preorder(tree, 2*index + 1);
        preorder(tree, 2*index + 2);
    }

    return;

}

int count(BST tree, int index){

	if((tree.array[index] == INT_MIN)||(tree.size < index))
		return 0;
	
	return (1 + count(tree, 2*index + 1) + count(tree, 2*index + 2));

}

